import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import fs from "fs";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form endpoint
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      const { name, email, subject, message } = req.body;
      
      // Validate input
      if (!name || !email || !message) {
        return res.status(400).json({ message: "Name, email, and message are required" });
      }
      
      // Here you would typically send an email or store the contact submission
      // For now, we'll just log it and return success
      console.log("Contact form submission:", { name, email, subject, message });
      
      res.status(200).json({ message: "Message sent successfully" });
    } catch (error) {
      console.error("Error processing contact form:", error);
      res.status(500).json({ message: "Error sending message" });
    }
  });

  // Endpoint to download CV
  app.get("/api/download-cv", (req: Request, res: Response) => {
    // In a real implementation, this would be a path to an actual CV file
    const filePath = path.join(__dirname, "assets", "Andrea_Runza_CV.pdf");
    
    // Since we don't have an actual file, we'll create a simple text file as a placeholder
    // Note: In a production environment, you would remove this and use a real PDF file
    const tempFilePath = path.join(__dirname, "temp_cv.txt");
    
    try {
      fs.writeFileSync(
        tempFilePath,
        "This is a placeholder for Andrea Runza's CV.\nIn a production environment, this would be an actual PDF file."
      );
      
      res.download(tempFilePath, "Andrea_Runza_CV.pdf", (err) => {
        // Delete the temporary file after download
        if (fs.existsSync(tempFilePath)) {
          fs.unlinkSync(tempFilePath);
        }
        
        if (err) {
          console.error("Error downloading CV:", err);
          res.status(500).json({ message: "Error downloading CV" });
        }
      });
    } catch (error) {
      console.error("Error preparing CV for download:", error);
      res.status(500).json({ message: "Error downloading CV" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
