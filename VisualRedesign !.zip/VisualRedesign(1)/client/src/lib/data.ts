export const personalInfo = {
  name: "Andrea Runza",
  title: "Full Stack Developer",
  summary: "Sviluppatore full stack con esperienza nello sviluppo di applicazioni web moderne ed efficienti. Appassionato di nuove tecnologie e di soluzioni innovative.",
  aboutParagraph1: "Sono uno sviluppatore full stack con solide basi di informatica e una passione per la creazione di soluzioni innovative. Ho iniziato il mio percorso nel mondo della tecnologia durante i miei studi universitari, dove ho scoperto la mia passione per la risoluzione dei problemi attraverso il codice.",
  aboutParagraph2: "Durante la mia carriera, ho lavorato su vari progetti, dalle applicazioni web ai sistemi di database, cercando sempre di creare prodotti efficienti e facili da usare. Credo nell'apprendimento continuo e nel rimanere aggiornato sulle ultime tecnologie e tendenze del settore.",
  aboutParagraph3: "Quando non programmo, mi piace esplorare nuovi sentieri escursionistici, leggere sulle novità tecnologiche e sperimentare nuove ricette in cucina.",
  location: "Milano, Italia",
  email: "andrea.runza@example.com",
  phone: "+39 123 456 7890",
  linkedin: "https://linkedin.com/in/andrearunza",
  github: "https://github.com/andrearunza",
  twitter: "https://twitter.com/andrearunza",
  instagram: "https://instagram.com/andrearunza"
};

export const experiences = [
  {
    title: "Senior Full Stack Developer",
    period: "Gen 2020 - Presente",
    company: "Tech Solutions Italia",
    description: "Responsabile dello sviluppo di applicazioni cloud, ottimizzazione delle prestazioni e miglioramento dell'esperienza utente. Collaborazione con team multifunzionali per implementare nuove funzionalità e risolvere problemi tecnici complessi.",
    skills: ["React", "Node.js", "AWS", "MongoDB"]
  },
  {
    title: "Web Developer",
    period: "Mar 2017 - Dic 2019",
    company: "Digital Innovations Milano",
    description: "Sviluppo e manutenzione di applicazioni web utilizzando framework JavaScript. Implementazione di design responsive e garanzia di compatibilità cross-browser. Partecipazione a code review e mentoring di sviluppatori junior.",
    skills: ["JavaScript", "Vue.js", "PHP", "MySQL"]
  },
  {
    title: "Junior Frontend Developer",
    period: "Giu 2015 - Feb 2017",
    company: "WebTech Studios Roma",
    description: "Supporto nello sviluppo di siti web e applicazioni web per clienti. Creazione di layout responsive, implementazione di componenti UI e risoluzione di bug. Collaborazione con designer per trasformare mockup in pagine web funzionali.",
    skills: ["HTML", "CSS", "jQuery", "WordPress"]
  }
];

export const education = [
  {
    degree: "Laurea Magistrale in Informatica",
    period: "2013 - 2015",
    institution: "Politecnico di Milano",
    description: "Specializzazione in Ingegneria del Software con focus su tecnologie web e sistemi distribuiti. Tesi di laurea su 'Ottimizzazione delle Prestazioni dei Database in Ambienti Cloud.'",
    courses: "Algoritmi Avanzati, Cloud Computing, Architettura Software, Data Mining"
  },
  {
    degree: "Laurea Triennale in Ingegneria Informatica",
    period: "2009 - 2013",
    institution: "Università degli Studi di Milano",
    description: "Acquisizione di solide basi in programmazione, algoritmi e progettazione di sistemi. Partecipazione a numerosi hackathon e competizioni di coding.",
    courses: "Strutture Dati, Sistemi Operativi, Gestione Database, Programmazione Orientata agli Oggetti"
  }
];

export const technicalSkills = [
  { name: "JavaScript", level: 95 },
  { name: "React", level: 90 },
  { name: "Node.js", level: 85 },
  { name: "HTML/CSS", level: 95 },
  { name: "TypeScript", level: 88 },
  { name: "Python", level: 80 }
];

export const professionalSkills = [
  { name: "Risoluzione Problemi", level: 90 },
  { name: "Collaborazione in Team", level: 95 },
  { name: "Gestione Progetti", level: 85 },
  { name: "Comunicazione", level: 90 },
  { name: "Adattabilità", level: 85 }
];

export const technologies = [
  "Git", "Docker", "AWS", "MongoDB", "MySQL", "PostgreSQL", "Redis", 
  "TypeScript", "Express.js", "GraphQL", "Jest", "Webpack", "Sass", "Tailwind CSS"
];

export const projects = [
  {
    title: "Piattaforma E-commerce",
    description: "Una soluzione e-commerce full-stack con gestione prodotti, carrello e elaborazione pagamenti. Realizzata con React, Node.js e MongoDB.",
    technologies: ["React", "Node.js", "MongoDB"],
    demoLink: "https://ecommerce-demo.com",
    codeLink: "https://github.com/andrearunza/ecommerce-platform"
  },
  {
    title: "App Gestione Attività",
    description: "Un'applicazione responsive per la gestione delle attività con funzionalità drag-and-drop, promemoria e collaborazione di team. Realizzata con Vue.js e Firebase.",
    technologies: ["Vue.js", "Firebase", "Vuex"],
    demoLink: "https://taskmanager-demo.com",
    codeLink: "https://github.com/andrearunza/task-manager"
  },
  {
    title: "Dashboard Meteo",
    description: "Un'applicazione meteo che mostra condizioni attuali e previsioni per diverse località. Include mappe interattive e visualizzazioni di dati storici.",
    technologies: ["JavaScript", "API Integration", "Chart.js"],
    demoLink: "https://weather-dashboard-demo.com",
    codeLink: "https://github.com/andrearunza/weather-dashboard"
  },
  {
    title: "Portfolio Personale",
    description: "Un sito web portfolio responsive e moderno realizzato con React, Tailwind CSS e animazioni Framer Motion per mostrare le mie competenze e progetti.",
    technologies: ["React", "Tailwind CSS", "Framer Motion"],
    demoLink: "#",
    codeLink: "https://github.com/andrearunza/portfolio"
  }
];
