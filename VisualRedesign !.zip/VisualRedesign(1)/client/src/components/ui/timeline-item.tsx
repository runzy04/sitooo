import { motion } from "framer-motion";
import { Briefcase, GraduationCap } from "lucide-react";

interface TimelineItemProps {
  icon: "briefcase" | "graduation";
  title: string;
  period: string;
  company: string;
  description: string;
  tags?: string[];
  extraInfo?: React.ReactNode;
  isLast?: boolean;
  variant?: "primary" | "secondary";
  bgColor?: string;
  delay?: number;
}

export default function TimelineItem({
  icon,
  title,
  period,
  company,
  description,
  tags,
  extraInfo,
  isLast = false,
  variant = "primary",
  bgColor = "bg-white",
  delay = 0
}: TimelineItemProps) {
  return (
    <motion.div 
      className={`timeline-item relative pl-12 ${isLast ? "" : "pb-12"}`}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
    >
      <style jsx>{`
        .timeline-item:not(:last-child)::after {
          content: '';
          position: absolute;
          left: 1.2rem;
          top: 2.5rem;
          bottom: -1.5rem;
          width: 2px;
          background-color: #E5E7EB;
        }
      `}</style>
      
      <div className={`absolute left-0 top-1 w-8 h-8 ${variant === "primary" ? "bg-primary" : "bg-secondary"} rounded-full flex items-center justify-center`}>
        {icon === "briefcase" ? (
          <Briefcase className="h-4 w-4 text-white" />
        ) : (
          <GraduationCap className="h-4 w-4 text-white" />
        )}
      </div>
      
      <div className={`${bgColor} p-6 rounded-lg shadow-md`}>
        <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
          <h3 className="text-xl font-semibold">{title}</h3>
          <div className="text-sm font-medium text-gray-500 mt-1 md:mt-0">
            <span>{period}</span> • <span>{company}</span>
          </div>
        </div>
        
        <p className="text-gray-700 mb-4">{description}</p>
        
        {tags && tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {tags.map((tag, index) => (
              <span 
                key={index} 
                className="px-3 py-1 bg-blue-100 text-primary text-sm rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>
        )}
        
        {extraInfo}
      </div>
    </motion.div>
  );
}
