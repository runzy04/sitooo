import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { FileDown } from "lucide-react";
import { personalInfo } from "@/lib/data";

export default function Hero() {
  return (
    <section 
      id="hero" 
      className="pt-24 md:pt-32 pb-16 md:pb-24 bg-gradient-to-br from-blue-50 to-gray-50"
    >
      <div className="container mx-auto px-6 flex flex-col md:flex-row items-center">
        <motion.div 
          className="md:w-1/2 mb-10 md:mb-0"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">{personalInfo.name}</h1>
          <h2 className="text-2xl md:text-3xl text-primary font-semibold mb-6">
            {personalInfo.title}
          </h2>
          <p className="text-lg mb-8 text-gray-600 max-w-lg">
            {personalInfo.summary}
          </p>
          <div className="flex space-x-4">
            <Button 
              asChild
              size="lg"
              className="bg-primary hover:bg-secondary transition duration-300"
            >
              <a href="#contact">Contact Me</a>
            </Button>
            <Button 
              asChild
              variant="outline" 
              size="lg"
              className="border-primary text-primary hover:bg-primary hover:text-white transition duration-300"
            >
              <a href="/api/download-cv">
                <FileDown className="mr-2 h-4 w-4" />
                Download CV
              </a>
            </Button>
          </div>
        </motion.div>
        
        <motion.div 
          className="md:w-1/2 flex justify-center"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-white shadow-xl">
            <svg className="absolute inset-0 w-full h-full text-gray-300" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 14.75c2.67 0 8 1.33 8 4v1.25H4v-1.25c0-2.67 5.33-4 8-4zm0-9.5a3.75 3.75 0 110 7.5 3.75 3.75 0 010-7.5z" />
            </svg>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
