import { motion } from "framer-motion";
import { experiences } from "@/lib/data";
import TimelineItem from "@/components/ui/timeline-item";

export default function Experience() {
  return (
    <section id="experience" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-3xl font-bold mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          Professional Experience
        </motion.h2>
        
        {experiences.map((experience, index) => (
          <TimelineItem
            key={index}
            icon="briefcase"
            title={experience.title}
            period={experience.period}
            company={experience.company}
            description={experience.description}
            tags={experience.skills}
            isLast={index === experiences.length - 1}
            delay={0.2 + index * 0.1}
          />
        ))}
      </div>
    </section>
  );
}
