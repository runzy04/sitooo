import { motion } from "framer-motion";
import { Mail, MapPin, Phone } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { personalInfo } from "@/lib/data";

export default function About() {
  return (
    <section id="about" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-3xl font-bold mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          About Me
        </motion.h2>
        
        <div className="flex flex-col md:flex-row items-center md:items-start">
          <motion.div 
            className="md:w-1/3 mb-8 md:mb-0 flex justify-center"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="w-64 h-64 overflow-hidden">
              <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                <svg className="w-full h-full text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 14.75c2.67 0 8 1.33 8 4v1.25H4v-1.25c0-2.67 5.33-4 8-4zm0-9.5a3.75 3.75 0 110 7.5 3.75 3.75 0 010-7.5z" />
                </svg>
              </div>
            </Card>
          </motion.div>
          
          <motion.div 
            className="md:w-2/3 md:pl-12"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <p className="text-lg mb-6 text-gray-700">
              {personalInfo.aboutParagraph1}
            </p>
            <p className="text-lg mb-6 text-gray-700">
              {personalInfo.aboutParagraph2}
            </p>
            <p className="text-lg mb-8 text-gray-700">
              {personalInfo.aboutParagraph3}
            </p>
            
            <div className="flex flex-wrap gap-6">
              <div className="flex items-center">
                <MapPin className="h-5 w-5 text-primary mr-2" />
                <span className="text-gray-700">{personalInfo.location}</span>
              </div>
              <div className="flex items-center">
                <Mail className="h-5 w-5 text-primary mr-2" />
                <a 
                  href={`mailto:${personalInfo.email}`} 
                  className="text-gray-700 hover:text-primary transition-colors"
                >
                  {personalInfo.email}
                </a>
              </div>
              <div className="flex items-center">
                <Phone className="h-5 w-5 text-primary mr-2" />
                <a 
                  href={`tel:${personalInfo.phone.replace(/\s+/g, '')}`}
                  className="text-gray-700 hover:text-primary transition-colors"
                >
                  {personalInfo.phone}
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
