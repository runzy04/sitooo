import { motion } from "framer-motion";
import { education } from "@/lib/data";
import TimelineItem from "@/components/ui/timeline-item";

export default function Education() {
  return (
    <section id="education" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-3xl font-bold mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          Education
        </motion.h2>
        
        {education.map((edu, index) => (
          <TimelineItem
            key={index}
            icon="graduation"
            title={edu.degree}
            period={edu.period}
            company={edu.institution}
            description={edu.description}
            extraInfo={edu.courses && (
              <div className="text-sm text-gray-600">
                <strong>Relevant Courses:</strong> {edu.courses}
              </div>
            )}
            isLast={index === education.length - 1}
            variant="secondary"
            bgColor="bg-gray-50"
            delay={0.2 + index * 0.1}
          />
        ))}
      </div>
    </section>
  );
}
